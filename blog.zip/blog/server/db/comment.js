const mongoose = require("mongoose");


module.exports = mongoose.model("comment",new mongoose.Schema({

}));