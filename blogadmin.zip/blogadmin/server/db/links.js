const mongoose = require("mongoose");


let links = mongoose.model("links",new mongoose.Schema({
  //名字
  name: {type:String,required:true},
  //网址url
  href: {type:String,required:true},
  //图标 url
  icon: {type:String,required:true},
  //描述
  des: {type:String,required:true}
}));


module.exports = links;
