<template>
  <h1>
    欢迎登陆后台管理系统~
  </h1>
</template>

<script>
  export default {
    name: "AdminIndex"
  }
</script>

<style scoped lang="less">
  h1{
    width: 100%;
    height: 100%;
    font-size: 50px;
    line-height: 60vh;
    text-align: center;
  }
</style>
